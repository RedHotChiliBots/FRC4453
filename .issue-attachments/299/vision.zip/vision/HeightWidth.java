 

public class HeightWidth {
	public double[] height = { 0 };
	public double[] width = { 0 };
	public double[] centerX = { 0 };
	public double[] centerY = { 0 };

	public HeightWidth() {
		height[0] = 0;
		width[0] = 0;
		centerX[0] = 0;
		centerY[0] = 0;
	}

	public HeightWidth(double h, double w, double cx, double cy) {
		height[0] = h;
		width[0] = w;
		centerX[0] = cx;
		centerY[0] = cy;
	}

}
