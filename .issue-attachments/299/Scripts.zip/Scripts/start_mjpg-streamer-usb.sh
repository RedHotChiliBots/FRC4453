
mjpg_streamer -o "output_http.so -w /www -p 1180" -i "input_uvc.so -d /dev/video0 -f 30 -r 640x480 -n" &

#mjpg_streamer -o "output_http.so -w ./www -p 1181" -i "input_uvc.so -d /dev/video0 -f 30 -r 640x480 -n" &

