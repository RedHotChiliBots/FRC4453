# Install iceweasel browser and geany editor

sudo apt-get install -y geany iceweasel

