. ~/Scripts/InitScript.sh

# Update existing packages
echo -e "${BLU} Update Existing Packages${NC}"
sudo apt-get update

# Install Java CMake Ant
echo -e "${BLU} Install New Packages${NC}"
sudo apt-get install oracle-java8-jdk cmake git ant

# Install dependency packages
echo -e "${BLU} Install Dependency Packages${NC}"
sudo apt-get install build-essential pkg-config
sudo apt-get install libjpeg-dev libtiff5-dev libjasper-dev libpng12-dev
sudo apt-get install libavcodec-dev libavformat-dev libswscale-dev libv4l-dev
sudo apt-get install libxvidcore-dev libx264-dev
sudo apt-get install libgtk2.0-dev
sudo apt-get install libatlas-base-dev gfortran
sudo apt-get install python2.7-dev python3-dev

#sudo apt-get install build-essential cmake cmake-curses-gui pkg-config libpng12-0 libpng12-dev \
#                     libpng++-dev libpng3 libpnglite-dev zlib1g-dbg zlib1g zlib1g-dev \
#                     libjpeg-dev libtiff5-dev libjasper-dev libpng12-dev \
#                     libjpeg8 libjpeg8-dbg libjpeg62-turbo-dev libjpeg-progs \
#                     libav-tools libavcodec-dev libavformat-dev libswscale-dev \
#                     libv4l-dev libxvidcore-dev libx264-dev \
#                     pngtools libtiff5 libtiff5-dev libtiffxx0c2 libtiff-tools
#sudo apt-get install libgstreamer0.10-0-dbg libgstreamer0.10-0 libgstreamer0.10-dev \
#                     libunicap2 libunicap2-dev libdc1394-22-dev libdc1394-22 libdc1394-utils \
#                     swig libv4l-0 libeigen3-dev libxine2-dev python-numpy \
#                     python-dev libgtk2.0-dev

# Update Environment Variables
echo -e "${BLU} Update Environment Variables${NC}"
echo "" >> ~/.bashrc
echo "export ANT_HOME=/usr/share/ant/" >> ~/.bashrc
echo "export PATH=${PATH}:${ANT_HOME}/bin" >> ~/.bashrc
echo "export JAVA_HOME=/usr/lib/jvm/jdk-8-oracle-arm32-vfp-hflt/" >> ~/.bashrc
echo "export PATH=$PATH:$JAVA_HOME/bin" >> ~/.bashrc

. ~/Scripts/RebootScript.sh
