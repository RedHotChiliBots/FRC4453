# Run slideshow

feh -Y -x -q -D 5 -B black -F -Z -z -r /media/
