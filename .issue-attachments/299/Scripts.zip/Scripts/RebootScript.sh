
echo -e >&2 "${GRN}
*****************
*** Rebooting *** 
*****************
"
read -n 1 -s

# Reboot
sudo reboot