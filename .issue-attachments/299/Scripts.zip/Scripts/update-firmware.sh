# Update firmware and reboot
sudo rpi-update
sudo reboot -n
