. ~/Scripts/InitScript.sh

# Download OpenCV
echo -e "${BLU} Download OpenCV${NC}"
wget https://codeload.github.com/Itseez/opencv/zip/3.1.0
mv 3.1.0 opencv.zip
if [ -d "opencv-3.1.0" ]; then
	rm -Rf opencv-3.1.0
fi
unzip opencv.zip 
cd opencv-3.1.0/

# Build OpenCV
echo -e "${BLU} Build OpenCV${NC}"
if [ ! -d "build" ]; then
	mkdir build
fi
cd build
cmake -D CMAKE_BUILD_TYPE=RELEASE -D WITH_OPENCL=OFF -D BUILD_PERF_TESTS=OFF -D BUILD_SHARED_LIBS=OFF -D JAVA_INCLUDE_PATH=$JAVA_HOME/include -D JAVA_AWT_LIBRARY=$JAVA_HOME/jre/lib/amd64/libawt.so -D JAVA_JVM_LIBRARY=$JAVA_HOME/jre/lib/arm/server/libjvm.so -D CMAKE_INSTALL_PREFIX=/usr/local ..
make clean
make -j4

# Install OpenCV
echo -e "${BLU} Install OpenCV${NC}"
sudo make install

# Verify Build/Install
echo -e "${BLU} Verify Build/Install${NC}"
echo "Listing lib/libopencv_java310.so"
ls -al lib/libopencv_java310.so
echo "Listing bin/opencv-310.jar"
ls -al bin/opencv-310.jar

. ~/Scripts/FinishScript.sh
