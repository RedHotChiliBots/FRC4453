# Install feh (slideshow) and xscreensaver

sudo apt-get install -y feh
sudo apt-get install -y xscreensaver
