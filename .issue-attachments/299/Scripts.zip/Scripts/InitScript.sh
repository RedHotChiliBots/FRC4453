RED='\033[0;31m' # Red
GRN='\033[0;32m' # Green
BLU='\033[0;34m' # Blue
NC='\033[0m' # No Color

# Abort handler executed on error
abort() {
    errcode=$? # save the exit code as the first thing done in the trap function
    echo >&2 "error $errorcode"
    echo >&2 "from $BASH_COMMAND"
    echo >&2 "on line ${BASH_LINENO[0]}"
    echo -e >&2 "${RED}
***************
*** ABORTED *** 
***************
"
    exit $errcode 
}

trap 'abort' ERR


