. ~/Scripts/InitScript.sh

# Update existing packages
echo -e "${BLU} Update Existing Packages${NC}"
sudo apt-get update

# Install new packages
echo -e "${BLU} Install New Packages${NC}"
sudo apt-get install git cmake libjpeg8-dev

if [ -d "mjpg-streamer" ]; then
	# Remove mjpg-streamer directory
	echo -e "${BLU} Remove mjpg-streamer Directory${NC}"
	rm -Rf mjpg-streamer
fi

# Clone mjpg-streamer
echo -e "${BLU} Clone mjpg-streamer Project${NC}"
git clone https://github.com/jacksonliam/mjpg-streamer.git

# Build mpjg-streamer
echo -e "${BLU} Make mpjq-streamer Project${NC}"
cd mjpg-streamer/mjpg-streamer-experimental
make clean
make -j4 all

# Install mpjg-streamer
echo -e "${BLU} Install mpjq-streamer${NC}"
sudo make install

. ~/Scripts/FinishScript.sh
