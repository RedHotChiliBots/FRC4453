# Update OS
sudo apt-get update
sudo apt-get -y upgrade
sudo apt-get -y autoremove
