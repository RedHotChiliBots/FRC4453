title="Red Hot Chili Bots Preso Kiosk"
prompt="Pick an option:"
options=("1) Who are the Red Hot Chili Bots?" "2) What is FIRST?" "3) Slideshow" "4) FTC Game Animation" "5) FRC Logo")

while opt=$(zenity --title="$title" --width=450 --height=250 \
                   --text="$prompt" --list \
                   --column="Options" "${options[@]}"); do

    case "$opt" in
#    "${options[0]}" ) zenity --info --text="You picked $opt, option 1";;
#    "${options[1]}" ) zenity --info --text="You picked $opt, option 2";;
#    "${options[2]}" ) zenity --info --text="You picked $opt, option 3";;

    "${options[0]}" ) okular --presentation --noraise --page 1 ~/Documents/rhcb-overview-condensed.pdf;;
    "${options[1]}" ) okular --presentation --noraise --page 1 ~/Documents/first-overview-condensed.pdf;;
    "${options[2]}" ) ~/Scripts/run-slideshow.sh;;
    "${options[3]}" ) omxplayer ~/Videos/FTC2016-2015GameAnimationNoIntroVelocityVortex-6Eyk5CJg41A.mp4;;
    "${options[4]}" ) sudo fbi -T 2 -nocomments -noverbose RedHotChiliBots-Clear.png;;

    *) zenity --error --text="Invalid option. Try another one.";;
    esac

done
